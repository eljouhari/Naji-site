// script.js
console.log("Site Najib El Jouhari chargé.");
